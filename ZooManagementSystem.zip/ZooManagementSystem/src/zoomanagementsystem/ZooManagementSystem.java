
package zoomanagementsystem;

// The main class
public class ZooManagementSystem {

    // Class Animal which is the parent class
   public static class Animal {
       
       //Defined Variables
        protected String name;
        protected int age;

        // Constructor to initialize name and age
        public Animal(String name, int age) {
            this.name = name;
            this.age = age;
        }

        // Method make a sound (to be overridden by subclasses)
        public void makeSound() {
            System.out.println("Animal Makes sound");
        }

        // Method for eating (to be overridden by subclasses)
        public void eat() {
            System.out.println("Animal is eating");
        }

        // Overloaded method to make a sound multiple times
        public void makeSound(int times) {
            for (int i = 0; i < times; i++) {
                makeSound();
            }
        }

        // Overloaded method for eating with a specific food type
        public void eat(String foodType) {
            System.out.println("Animal is eating " + foodType);
        }
    } // End of Class Animal
   
   // Lion class inherits features of the parent class Animal
    public static class Lion extends Animal {

        // Constructor to initialize name and age from the Parent class
        public Lion(String name, int age) {
            
            // The super Key word initializes the variable from the parent class in the child class Lion
            super(name, age);
        }

        // Overridden method to make a lion sound
        @Override
        public void makeSound() {
            System.out.println("Roar");
        }

        // Overridden method for lion eating behavior
        @Override
        public void eat() {
            System.out.println("Eating meat");
        }
    }

    // Elephant class in herits features of the parent class Animal
    public static class Elephant extends Animal {

        // Constructor to initialize name and age
        public Elephant(String name, int age) {
            super(name, age);
        }

        // Overridden method to make an elephant sound
        @Override
        public void makeSound() {
            System.out.println("Trumpet");
        }

        // Overridden method for elephant eating behavior
        @Override
        public void eat() {
            System.out.println("Eating grass");
        }
    }

    // Monkey class: subclass of Animal
    public static class Monkey extends Animal {

        // Constructor to initialize name and age
        public Monkey(String name, int age) {
            super(name, age);
        }

        // Overridden method to make a monkey sound
        @Override
        public void makeSound() {
            System.out.println("Chatter");
        }

        // Overridden method for monkey eating behavior
        @Override
        public void eat() {
            System.out.println("Eating bananas");
        }
    }

    // The main method to run the zooManagement system
    public static void main(String[] args) {
        // Creating Objects of all the classes (Lion, Elephant, and Monkey) to run the methods
        
        Animal lion = new Lion("Simba", 75);
        Animal elephant = new Elephant("Njonvu", 100);
        Animal monkey = new Monkey("Nkima", 43);

        // Demonstrating Lion behavior
        System.out.println("Lion:");
        lion.makeSound();           // Lion making sound
        lion.eat();                 // Lion eating
        lion.makeSound(3);          // Lion making sound three times
        lion.eat("The Fresh Meat");          // Lion eating a specific food type

        // Demonstrating Elephant behavior
        System.out.println("\nElephant:");
        elephant.makeSound();       // Elephant making sound
        elephant.eat();             // Elephant eating
        elephant.makeSound(2);      // Elephant making sound two times
        elephant.eat("Green pasture");        // Elephant eating a specific food type

        // Demonstrating Monkey behavior
        System.out.println("\nMonkey:");
        monkey.makeSound();         // Monkey making sound
        monkey.eat();               // Monkey eating
        monkey.makeSound(4);        // Monkey making sound four times
        monkey.eat("Yellow banana");  // Monkey eating a specific food type
        
        
        
         }
    
}
